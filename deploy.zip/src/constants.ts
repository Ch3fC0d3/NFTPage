// Set your deployed contract address and ABI here
export const CONTRACT_ADDRESS = "0xDDD3e036664e7A06244E4892Fcefb7b9f70BfFd8"; // Sepolia contract address
export { default as CONTRACT_ABI } from "./abi.json";
